package team23.officefinder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import uk.liamp.teamproject.R;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }

    public void toggleTakeLift(View view){
        //add method
    }
}
